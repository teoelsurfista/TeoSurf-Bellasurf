# Teo Surf 🌊
An interactive surf forecast app built with HTML, JS, and Chart.js.

## Features
- 10-day marine forecast (wave height, wind speed, tides)
- Rating system from ⭐ to ⭐⭐⭐
- Visual wave icons
- Built for 3 beaches in Málaga

## Deployment
Ready to deploy on [Vercel](https://vercel.com/).
